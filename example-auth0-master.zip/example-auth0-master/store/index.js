// Enable store for auth module
