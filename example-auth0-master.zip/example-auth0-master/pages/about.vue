<template>
  <div>
    <h1>About Page</h1>
    <p>Hello, I am the about page :)</p>
  </div>
</template>
